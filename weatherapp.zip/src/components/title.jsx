import React, { Component } from "react";
const Title = () => {
  return (
    <div className="parent">
      <div className="title_container">
        <h1>Weather app</h1>
        <p>find out weather in your city...</p>
      </div>
    </div>
  );
};

export default Title;
