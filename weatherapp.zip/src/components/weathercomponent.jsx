import React, { Component } from "react";
class WeatherComponent extends Component {
  state = {};
  render() {
    let { currentWeather } = this.props;
    let weather = currentWeather.fetched_data;
    return (
      <React.Fragment>
        <div>
          <span>Location: </span>
          <span>{weather.temp}</span>
        </div>
        <div>
          <span>Location: </span>
          <span>Kiev, Ukraine</span>
        </div>
        <div>
          <span>Location: </span>
          <span>Kiev, Ukraine</span>
        </div>
      </React.Fragment>
    );
  }
}

export default WeatherComponent;
